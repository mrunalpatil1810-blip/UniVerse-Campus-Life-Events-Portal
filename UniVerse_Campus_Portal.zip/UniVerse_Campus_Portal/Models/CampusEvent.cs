using System.ComponentModel.DataAnnotations;

namespace UniVerse.Models;

public class CampusEvent
{
    public int Id { get; set; }

    [Required, StringLength(90, MinimumLength = 4)]
    [Display(Name = "Event title")]
    public string Title { get; set; } = "";

    [Required]
    public string Category { get; set; } = "Workshop";

    [Required, DataType(DataType.Date)]
    [Display(Name = "Event date")]
    public DateTime Date { get; set; } = DateTime.Today.AddDays(1);

    [Required]
    [Display(Name = "Start time")]
    public string Time { get; set; } = "10:00 AM";

    [Required, StringLength(80)]
    public string Venue { get; set; } = "";

    [Required, StringLength(70)]
    public string Host { get; set; } = "";

    [Required, StringLength(800, MinimumLength = 15)]
    public string Description { get; set; } = "";

    [Range(5, 1000)]
    public int Capacity { get; set; } = 50;

    public string Accent { get; set; } = "violet";
}
