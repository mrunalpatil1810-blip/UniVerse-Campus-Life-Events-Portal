# UniVerse — Campus Life & Events Portal

UniVerse is a responsive ASP.NET Core MVC website concept for discovering and managing campus events. It is designed as a college mini-project with a modern editorial look, colorful event cards, responsive layouts, and a working database.

## Features
- Campus discovery homepage with event statistics and search
- Filter events by category and search by title, venue, or host
- Event details page
- Create, read, edit, and delete events (CRUD)
- Form validation using Data Annotations
- SQLite database through Entity Framework Core
- Sample events inserted automatically on first run
- Responsive mobile/tablet/desktop layout

## Technology
- ASP.NET Core MVC / C#
- Entity Framework Core
- SQLite (no separate database server needed)
- Razor views, HTML, CSS, Bootstrap 5

> If your college rubric specifically requires MySQL, confirm that SQLite is acceptable before submission. This project intentionally uses SQLite to keep setup simple.

## Run in VS Code (Windows)
1. Install the .NET 10 SDK and Visual Studio Code.
2. Extract the ZIP file.
3. In VS Code, choose **File → Open Folder** and select the folder that directly contains `UniVerse.csproj`.
4. Open **Terminal → New Terminal**.
5. Run:
   ```powershell
   dotnet --list-sdks
   dotnet restore
   dotnet run
   ```
6. Open the local URL shown in the terminal, usually `https://localhost:xxxx` or `http://localhost:xxxx`.
7. To stop the website, click the terminal and press `Ctrl + C`.

If the terminal says no project file was found, you are in the wrong folder. Run `Get-ChildItem -Recurse -Filter UniVerse.csproj`, then `cd` to the folder that contains it.

## GitHub upload
See `GITHUB_STEPS.md` for beginner-friendly instructions.

## Important
This is a learning/demo project. Review the code, change the sample event details, and test the forms before presenting it.
