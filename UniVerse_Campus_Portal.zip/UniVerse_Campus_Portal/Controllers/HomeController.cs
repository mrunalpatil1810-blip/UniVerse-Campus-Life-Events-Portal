using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UniVerse.Data;

namespace UniVerse.Controllers;

public class HomeController : Controller
{
    private readonly CampusDbContext _db;
    public HomeController(CampusDbContext db) => _db = db;

    public async Task<IActionResult> Index(string? search, string? category)
    {
        var query = _db.Events.AsNoTracking().AsQueryable();

        if (!string.IsNullOrWhiteSpace(search))
            query = query.Where(e => e.Title.Contains(search) || e.Venue.Contains(search) || e.Host.Contains(search));

        if (!string.IsNullOrWhiteSpace(category) && category != "All")
            query = query.Where(e => e.Category == category);

        ViewBag.Search = search;
        ViewBag.Category = category ?? "All";
        ViewBag.TotalEvents = await _db.Events.CountAsync();
        ViewBag.UpcomingEvents = await _db.Events.CountAsync(e => e.Date.Date >= DateTime.Today);
        ViewBag.Categories = await _db.Events.Select(e => e.Category).Distinct().OrderBy(c => c).ToListAsync();

        var events = await query.OrderBy(e => e.Date).ToListAsync();
        return View(events);
    }

    public async Task<IActionResult> Details(int id)
    {
        var campusEvent = await _db.Events.AsNoTracking().FirstOrDefaultAsync(e => e.Id == id);
        return campusEvent == null ? NotFound() : View(campusEvent);
    }
}
