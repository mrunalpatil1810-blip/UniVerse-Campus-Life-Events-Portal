using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UniVerse.Data;
using UniVerse.Models;

namespace UniVerse.Controllers;

public class EventsController : Controller
{
    private readonly CampusDbContext _db;
    public EventsController(CampusDbContext db) => _db = db;

    public async Task<IActionResult> Index()
        => View(await _db.Events.AsNoTracking().OrderBy(e => e.Date).ToListAsync());

    public IActionResult Create() => View(new CampusEvent { Date = DateTime.Today.AddDays(1) });

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(CampusEvent campusEvent)
    {
        if (!ModelState.IsValid) return View(campusEvent);
        _db.Events.Add(campusEvent);
        await _db.SaveChangesAsync();
        TempData["Notice"] = "Your event is live. Let the campus know!";
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Edit(int id)
    {
        var campusEvent = await _db.Events.FindAsync(id);
        return campusEvent == null ? NotFound() : View(campusEvent);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, CampusEvent campusEvent)
    {
        if (id != campusEvent.Id) return BadRequest();
        if (!ModelState.IsValid) return View(campusEvent);

        _db.Events.Update(campusEvent);
        await _db.SaveChangesAsync();
        TempData["Notice"] = "Event details updated successfully.";
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Delete(int id)
    {
        var campusEvent = await _db.Events.AsNoTracking().FirstOrDefaultAsync(e => e.Id == id);
        return campusEvent == null ? NotFound() : View(campusEvent);
    }

    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var campusEvent = await _db.Events.FindAsync(id);
        if (campusEvent != null)
        {
            _db.Events.Remove(campusEvent);
            await _db.SaveChangesAsync();
            TempData["Notice"] = "Event removed.";
        }
        return RedirectToAction(nameof(Index));
    }
}
