using UniVerse.Models;

namespace UniVerse.Data;

public static class SeedData
{
    public static void Initialize(CampusDbContext db)
    {
        if (db.Events.Any()) return;

        db.Events.AddRange(
            new CampusEvent {
                Title = "Design Jam: Make It Matter",
                Category = "Workshop",
                Date = DateTime.Today.AddDays(4),
                Time = "10:30 AM",
                Venue = "Innovation Lab",
                Host = "Design Society",
                Description = "A friendly, hands-on design sprint. Bring an idea, team up, and prototype a solution to a campus-life challenge.",
                Capacity = 60,
                Accent = "violet"
            },
            new CampusEvent {
                Title = "Code & Chai",
                Category = "Technology",
                Date = DateTime.Today.AddDays(7),
                Time = "2:00 PM",
                Venue = "Computer Lab 2",
                Host = "Developer Club",
                Description = "Pair-programming, mini coding puzzles, and a relaxed space to learn from fellow builders. All experience levels welcome.",
                Capacity = 45,
                Accent = "mint"
            },
            new CampusEvent {
                Title = "Open Mic Under The Stars",
                Category = "Culture",
                Date = DateTime.Today.AddDays(10),
                Time = "5:30 PM",
                Venue = "Central Courtyard",
                Host = "Cultural Committee",
                Description = "Poetry, acoustic music, storytelling, and performances from the campus community. Come perform or cheer people on.",
                Capacity = 120,
                Accent = "coral"
            },
            new CampusEvent {
                Title = "Future Founders Meetup",
                Category = "Networking",
                Date = DateTime.Today.AddDays(13),
                Time = "11:00 AM",
                Venue = "Seminar Hall A",
                Host = "Entrepreneurship Cell",
                Description = "Meet student founders, exchange early-stage ideas, and learn how to turn a small campus project into something useful.",
                Capacity = 80,
                Accent = "blue"
            }
        );
        db.SaveChanges();
    }
}
