using Microsoft.EntityFrameworkCore;
using UniVerse.Models;

namespace UniVerse.Data;

public class CampusDbContext : DbContext
{
    public CampusDbContext(DbContextOptions<CampusDbContext> options) : base(options) { }

    public DbSet<CampusEvent> Events => Set<CampusEvent>();
}
