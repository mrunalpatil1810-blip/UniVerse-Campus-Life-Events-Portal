# Upload UniVerse to GitHub — beginner steps

## Option A: Using GitHub website + VS Code (recommended)

### 1. Create a repository
1. Sign in at https://github.com.
2. Click the **+** icon near the top-right, then **New repository**.
3. Repository name: `UniVerse-Campus-Portal`
4. Description: `Responsive campus events portal built with ASP.NET Core MVC and SQLite`
5. Choose **Public** if your teacher needs to view it, or **Private** if you only want to share it with selected people.
6. Do **not** add a README, `.gitignore`, or licence because this project already contains those files.
7. Click **Create repository**. Keep that page open and copy the repository URL, for example `https://github.com/YOUR-USERNAME/UniVerse-Campus-Portal.git`.

### 2. Open the correct project folder
1. Extract the project ZIP.
2. Open VS Code.
3. Choose **File → Open Folder**.
4. Select the folder that directly contains `UniVerse.csproj`, `Program.cs`, `Controllers`, `Models`, and `Views`.
5. Choose **Terminal → New Terminal**.
6. Check the folder by running:
   ```powershell
   Get-ChildItem
   ```
   You should see `UniVerse.csproj`.

### 3. Install/check Git
In the VS Code terminal, run:
```powershell
git --version
```
If Windows says Git is not recognised, install Git for Windows from https://git-scm.com/download/win, then close and reopen VS Code.

### 4. Upload using commands
Replace the URL below with your own repository URL copied from GitHub. Run each command one by one:
```powershell
git init
git add .
git status
git commit -m "Initial commit: UniVerse campus portal"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/UniVerse-Campus-Portal.git
git push -u origin main
```
- If Git asks for your name/email, set them with your own details:
  ```powershell
  git config --global user.name "Your Name"
  git config --global user.email "your-github-email@example.com"
  ```
  Then repeat the commit command.
- When asked to sign in, complete the GitHub browser sign-in prompt.
- Do not share your password or access token with anyone.

### 5. Confirm the upload
Refresh your repository page. You should see folders such as `Controllers`, `Data`, `Models`, `Views`, and files such as `Program.cs`, `UniVerse.csproj`, and `README.md`.

## Option B: Upload through GitHub website (no Git commands)
1. Create a new repository on GitHub.
2. Open it and choose **Add file → Upload files**.
3. Extract the ZIP first. Open the extracted project folder and select its files/folders. Do not upload the ZIP itself if your teacher needs to see the source code.
4. Drag the project files and folders into the upload area.
5. Scroll down, enter commit message `Upload UniVerse campus portal`, and click **Commit changes**.

## If you get an error
- `fatal: remote origin already exists`: run `git remote -v`. If the URL is wrong, run `git remote set-url origin https://github.com/YOUR-USERNAME/UniVerse-Campus-Portal.git`.
- `nothing to commit`: run `git status` and check whether you are in the correct project folder.
- `rejected` because remote contains files: if you created a README on GitHub, the easiest beginner fix is to create a new empty repository without README and repeat, or ask before trying merge commands.
- Do not upload `bin`, `obj`, `.vs`, or the generated `universe-campus.db`; `.gitignore` excludes them.
